# -*- coding: utf-8 -*-
import tkinter as tk
from tkinter import ttk, messagebox
from personajes_dao import crear_tabla, borrar_tabla
from personajes_dao import Personajes, guardar, listar, editar, eliminar

class Frame(tk.Frame):
    def __init__(self, root=None):
        super().__init__(root, width=480, height=320)
        self.root = root
        self.pack()
        self.config(bg='lightgray') 
        self.barra_menu()
        self.id_personajes = None
        
        self.campos_personajes()
        self.desabilitar_campos()
        self.tabla_personajes()
        
    def campos_personajes(self):
        
        #Labels de cada campo
        self.label_nombre = tk.Label(self, text = 'Nombre:' )
        self.label_nombre.config(font = ('Arial', 12, 'bold' ))
        self.label_nombre.grid(row = 0, column = 0, padx=10, pady=10)
        
        self.label_franquicia = tk.Label(self, text = 'Franquicia:' )
        self.label_franquicia.config(font = ('Arial', 12, 'bold' ))
        self.label_franquicia.grid(row = 1, column = 0, padx=10, pady=10)
        
        self.label_poder = tk.Label(self, text = 'Poder Principal:' )
        self.label_poder.config(font = ('Arial', 12, 'bold' ))
        self.label_poder.grid(row = 2, column = 0, padx=10, pady=10)
        
        #Entrys de cada campo
        self.mi_nombre = tk.StringVar()
        self.entry_nombre = tk.Entry(self, textvariable = self.mi_nombre)
        self.entry_nombre.config(width = 50, font = ('Arial', 12,))
        self.entry_nombre.grid(row = 0, column = 1, padx=10, pady=10, columnspan=2) 
        
        self.mi_franquicia = tk.StringVar()
        self.entry_franquicia = tk.Entry(self, textvariable = self.mi_franquicia)
        self.entry_franquicia.config(width = 50, font = ('Arial', 12,))
        self.entry_franquicia.grid(row = 1, column = 1, padx=10, pady=10, columnspan=2) 
    
        self.mi_poder = tk.StringVar()
        self.entry_poder = tk.Entry(self, textvariable = self.mi_poder)
        self.entry_poder.config(width = 50, font = ('Arial', 12,))
        self.entry_poder.grid(row = 2, column = 1, padx=10, pady=10, columnspan=2) 
    
        #Botones Nuevo
        self.boton_nuevo = tk.Button(self, text="Nuevo", command = self.habilitar_campos)
        self.boton_nuevo.config(width = 20, font = ('Arial', 12, 'bold' ),
                                fg = '#000000', bg = '#7FFFD4',
                                cursor = 'hand2', activebackground='#35BD6F')
        self.boton_nuevo.grid(row = 3, column = 0, padx=10, pady=10)
        
        #Botones guardar
        self.boton_guardar = tk.Button(self, text="Guardar", command = self.guardar_datos)
        self.boton_guardar.config(width = 20, font = ('Arial', 12, 'bold' ),
                                fg = '#000000', bg = '#4DD0E1',
                                cursor = 'hand2', activebackground='#35BD6F')
        self.boton_guardar.grid(row = 3, column = 1, padx=10, pady=10)
        
        #Botones cancelar
        self.boton_cancelar = tk.Button(self, text="Cancelar", command = self.desabilitar_campos)
        self.boton_cancelar.config(width = 20, font = ('Arial', 12, 'bold' ),
                                fg = '#000000', bg = '#FF5722',
                                cursor = 'hand2', activebackground='#35BD6F')
        self.boton_cancelar.grid(row = 3, column = 2, padx=10, pady=10)
        
    def habilitar_campos(self):
            self.mi_nombre.set('')
            self.mi_franquicia.set('')
            self.mi_poder.set('')
            
            self.entry_nombre.config(state='normal')
            self.entry_franquicia.config(state='normal')
            self.entry_poder.config(state='normal')
            
            self.boton_guardar.config(state='normal')
            self.boton_cancelar.config(state='normal')
        
    def desabilitar_campos(self):
            self.id_personajes = None
            self.mi_nombre.set('')
            self.mi_franquicia.set('')
            self.mi_poder.set('')
            
            self.entry_nombre.config(state='disabled')
            self.entry_franquicia.config(state='disabled')
            self.entry_poder.config(state='disabled')
            
            self.boton_guardar.config(state='disabled')
            self.boton_cancelar.config(state='disabled')
            
    def guardar_datos(self):
        personajes = Personajes(
            self.mi_nombre.get(),
            self.mi_franquicia.get(),
            self.mi_poder.get(),
        )
        
        if self.id_personajes == None:
            guardar(personajes)
        else:
            editar(personajes, self.id_personajes)
            
        self.tabla_personajes()
        
        #Desabilitar campos
        self.desabilitar_campos()
    
    def tabla_personajes(self):
        
        #Recuperar la lista de los personajes
        self.lista_personajes = listar()
        self.lista_personajes.reverse()
        
        self.tabla = ttk .Treeview(self,
        column = ('Nombre', 'Franquicia', 'Poder Principal'))
        self.tabla.grid(row = 4, column = 0, columnspan = 4, sticky = 'nse' )
        
        #Scrollbar para la tabla si excede 10 registro
        self.scroll = ttk.Scrollbar(self,
        orient = 'vertical', command = self.tabla.yview)
        self.scroll.grid(row = 4, column = 4, sticky = 'nse')
        self.tabla.configure(yscrollcommand = self.scroll.set)
        
        self.tabla.heading('#0', text = 'ID' )
        self.tabla.heading('#1', text = 'NOMBRE' )
        self.tabla.heading('#2', text = 'FRANQUICIA' )
        self.tabla.heading('#3', text = 'PODER PRINCIPAL' )
        
        #Iterar la lista de los personajes
        for p in self.lista_personajes:
            self.tabla.insert('',0, text=p[0],
            values = (p[1], p[2], p[3]) )
        
        #Boton editar
        self.boton_editar = tk.Button(self, text="Editar", command = self.editar_datos)
        self.boton_editar.config(width = 20, font = ('Arial', 12, 'bold' ),
                                fg = '#000000', bg = '#32CD32',
                                cursor = 'hand2', activebackground='#35BD6F')
        self.boton_editar.grid(row = 5, column = 0, padx=10, pady=10)
        
        #Botones eliminar
        self.boton_eliminar = tk.Button(self, text="Eliminar", command = self.eliminar_datos)
        self.boton_eliminar.config(width = 20, font = ('Arial', 12, 'bold' ),
                                fg = '#000000', bg = '#FF0000',
                                cursor = 'hand2', activebackground='#E15370')
        self.boton_eliminar.grid(row = 5, column = 1, padx=10, pady=10)
        
    def editar_datos(self):
        try:
            self.id_personajes = self.tabla.item(self.tabla.selection())['text']
            
            self.nombre_personajes = self.tabla.item(
                self.tabla.selection()) ['values'][0]
            
            self.franquicia_personajes = self.tabla.item(
                self.tabla.selection()) ['values'][1]
            
            self.poder_personajes = self.tabla.item(
                self.tabla.selection()) ['values'][2]
            
            self.habilitar_campos()
            
            self.entry_nombre.insert(0, self.nombre_personajes)
            self.entry_franquicia.insert(0, self.franquicia_personajes)
            self.entry_poder.insert(0, self.poder_personajes)
            
        except:
            titulo = 'Edición de datos'
            mensaje = 'No ha seleccionado ningún registro'
            messagebox.showerror(titulo, mensaje)
            
    def eliminar_datos(self):
        try:
            
            self.id_personajes = self.tabla.item(self.tabla.selection())['text']
            eliminar(self.id_personajes)
            
            self.tabla_personajes()
            self.id_personajes = None
        
        except:
            titulo = 'Eliminar un Registro'
            mensaje = 'No ha seleccionado ningún registro'
            messagebox.showerror(titulo, mensaje)
    
    def limpiar_tabla(self):
        
        for i in self.tabla.get_children():
           self.tabla.delete(i)
           
    def barra_menu(self):
        barra_menu = tk.Menu(self.root)
        self.root.config(menu = barra_menu, width = 300, height = 300)
        
        menu_inicio = tk.Menu(barra_menu, tearoff = 0)
        barra_menu.add_cascade(label = 'Inicio', menu = menu_inicio)
        
        menu_inicio.add_command(label = 'Crear Registro en DB', command = crear_tabla)
        menu_inicio.add_command(label = 'Eliminar Registro en DB', command = self.eliminar_tabla)
        menu_inicio.add_command(label = 'Salir', command = self.root.destroy)
        
        barra_menu.add_cascade(label = 'Consultas')
        barra_menu.add_cascade(label = 'Configuracion')
        barra_menu.add_cascade(label = 'Ayuda')
        
    def eliminar_tabla(self):
        borrar_tabla()
        self.limpiar_tabla()
        
            
            